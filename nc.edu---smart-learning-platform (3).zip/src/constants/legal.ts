export const TERMS_AND_CONDITIONS = `
TERMS AND CONDITIONS OF SERVICE
Last Updated: May 16, 2026

1. ACCEPTANCE OF TERMS
By accessing or using this application (the "Service"), you agree to be bound by these Terms and Conditions. If you do not agree to all of these terms, you are prohibited from using the Service and must discontinue use immediately.

2. ELIGIBILITY
You must be at least 13 years of age to use this Service. By using the Service, you represent and warrant that you meet this age requirement.

3. USER ACCOUNTS
When you create an account, you must provide accurate and complete information. You are solely responsible for the activity that occurs on your account and for keeping your account password secure.

4. INTELLECTUAL PROPERTY
The Service and its original content, features, and functionality are and will remain the exclusive property of the Enterprise and its licensors. Our trademarks and trade dress may not be used in connection with any product or service without the prior written symbols.

5. LIMITATION OF LIABILITY
IN NO EVENT SHALL THE ENTERPRISE, NOR ITS DIRECTORS, EMPLOYEES, PARTNERS, AGENTS, SUPPLIERS, OR AFFILIATES, BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL OR PUNITIVE DAMAGES, INCLUDING WITHOUT LIMITATION, LOSS OF PROFITS, DATA, USE, GOODWILL, OR OTHER INTANGIBLE LOSSES, RESULTING FROM (I) YOUR ACCESS TO OR USE OF OR INABILITY TO ACCESS OR USE THE SERVICE; (II) ANY CONDUCT OR CONTENT OF ANY THIRD PARTY ON THE SERVICE; (III) ANY CONTENT OBTAINED FROM THE SERVICE; AND (IV) UNAUTHORIZED ACCESS, USE OR ALTERATION OF YOUR TRANSMISSIONS OR CONTENT, WHETHER BASED ON WARRANTY, CONTRACT, TORT (INCLUDING NEGLIGENCE) OR ANY OTHER LEGAL THEORY, WHETHER OR NOT WE HAVE BEEN INFORMED OF THE POSSIBILITY OF SUCH DAMAGE.

6. DISCLAIMER OF WARRANTIES
YOUR USE OF THE SERVICE IS AT YOUR SOLE RISK. THE SERVICE IS PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS. THE SERVICE IS PROVIDED WITHOUT WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT OR COURSE OF PERFORMANCE.

7. GOVERNING LAW
These Terms shall be governed and construed in accordance with the laws, without regard to its conflict of law provisions.

8. INDEMNIFICATION
You agree to defend, indemnify and hold harmless the Enterprise and its licensee and licensors, and their employees, contractors, agents, officers and directors, from and against any and all claims, damages, obligations, losses, liabilities, costs or debt, and expenses (including but not limited to attorney's fees), resulting from or arising out of a) your use and access of the Service, by you or any person using your account and password, or b) a breach of these Terms.

9. TERMINATION
We may terminate or suspend your account and bar access to the Service immediately, without prior notice or liability, under our sole discretion, for any reason whatsoever and without limitation, including but not limited to a breach of the Terms.

10. CHANGES
We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.

11. CONTACT US
If you have any questions about these Terms, please contact us.
`.repeat(5);

export const PRIVACY_POLICY = `
PRIVACY POLICY
Last Updated: May 16, 2026

1. INFORMATION WE COLLECT
We collect several different types of information for various purposes to provide and improve our Service to you. This may include personal data such as your email address, name, and usage data.

2. USE OF DATA
We use the collected data for various purposes:
- To provide and maintain our Service
- To notify you about changes to our Service
- To provide customer support
- To gather analysis or valuable information so that we can improve our Service
- To monitor the usage of our Service
- To detect, prevent and address technical issues

3. TRANSFERS OF DATA
Your information, including Personal Data, may be transferred to — and maintained on — computers located outside of your state, province, country or other governmental jurisdiction where the data protection laws may differ than those from your jurisdiction.

4. DISCLOSURE OF DATA
We may disclose your Personal Data in the good faith belief that such action is necessary to:
- To comply with a legal obligation
- To protect and defend the rights or property of the Enterprise
- To prevent or investigate possible wrongdoing in connection with the Service
- To protect the personal safety of users of the Service or the public
- To protect against legal liability

5. SECURITY OF DATA
The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.

6. SERVICE PROVIDERS
We may employ third party companies and individuals to facilitate our Service ("Service Providers"), to provide the Service on our behalf, to perform Service-related services or to assist us in analyzing how our Service is used.

7. LINKS TO OTHER SITES
Our Service may contain links to other sites that are not operated by us. If you click on a third party link, you will be directed to that third party's site. We strongly advise you to review the Privacy Policy of every site you visit.

8. CHILDREN'S PRIVACY
Our Service does not address anyone under the age of 13 ("Children"). We do not knowingly collect personally identifiable information from anyone under the age of 13.

9. CHAT AND COMMUNICATION SAFETY
All communications, including chat messages and information shared within the platform, are stored securely using industry-standard encryption and access controls. Access is restricted to authorized personnel only for maintenance and support purposes.

10. CHANGES TO THIS PRIVACY POLICY
We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.

11. CONTACT US
If you have any questions about this Privacy Policy, please contact us.
`.repeat(5);
