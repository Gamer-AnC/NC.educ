export type Language = 'ENGLISH' | 'FRENCH' | 'CHINESE' | 'SPANISH';

export const TRANSLATIONS: Record<Language, Record<string, string>> = {
  ENGLISH: {
    // Nav & General
    home: "Home",
    tutors: "Tutors",
    students: "Students",
    community: "Community",
    signIn: "Sign In",
    signOut: "Sign Out",
    welcome: "Welcome",
    studentPortal: "Student Portal",
    
    // Landing Page
    heroTitle: "Where learning meets support",
    heroDesc: "NC.edu is a smart learning platform that connects students who excel academically with students who need help.",
    joinAsStudent: "Join as Student",
    applyAsTutor: "Apply as Tutor",
    pathwaysHeading: "Specialized Learning Pathways",
    welcomeBack: "Welcome back! Your Student ID is",
    upgradePro: "Upgrade to Pro",
    communityTitle: "Build The Future Together",
    communityDesc: "At NC.edu, nobody learns alone. Every strong student becomes a mentor, and every struggling student gets support.",
    joinCommunity: "Join The Community",
    privacyText: "Privacy",
    termsText: "Terms",
    contactText: "Contact",
    
    peerTutoring: "Peer Tutoring",
    peerTutoringDesc: "Students who understand subjects deeply can teach others in simple and friendly ways.",
    studyGroups: "Study Groups",
    studyGroupsDesc: "Create or join study groups and prepare together for exams and assignments.",
    liveChat: "Live Chat",
    liveChatDesc: "Instantly ask questions and receive explanations from top-performing students.",
    getStarted: "Get Started",
    premiumFeature: "Premium Feature",
    upgradeDesc: "Upgrade to join study groups and live chats.",
    upgradeNow: "Upgrade Now",
    
    // Student Dashboard
    studentDashboardTitle: "NC.edu Student Dashboard",
    studentDashboardDesc: "Your gateway to academic excellence and expert tutoring.",
    welcomeStudent: "Welcome Student",
    welcomeStudentDesc: "Find expert tutors, ask your toughest questions, join collaborative study groups, and take control of your academic performance with AI-powered tools.",
    studentExperiences: "Student Experiences",
    
    allSubjectsTitle: "All Subjects",
    allSubjectsDesc: "Connect with top tutors across any academic field - from Mathematics to Literature.",
    findTutorBtn: "Find Tutor",
    
    joinClassTitle: "Join Class",
    joinClassDesc: "Learn complex topics through structured lessons and AI-guided study schedules.",
    joinClassBtn: "Join Class",
    
    askQuestionsTitle: "Ask Questions",
    askQuestionsDesc: "Get instant answers for difficult problems using our expert-trained AI model.",
    askQuestionBtn: "Ask Question",
    
    scanAndSolveTitle: "AI Scan & Solve",
    scanAndSolveDesc: "Scan or snap a photo of any handwritten equation, homework, diagram, or notes. Get immediate, step-by-step solutions!",
    scanAndSolveBtn: "Scan & Solve",

    // Action wizard / AI Chat
    aiWelcomeAsk: "Hello! I am your premium AI Academic Tutor. I am ready to help you master the subject: ",
    aiWelcomeAskSuffix: "! Feel free to ask your questions or request practice exercises.",
    aiWelcomeJoin: "Hello! Welcome to your premium Study Path for ",
    aiWelcomeJoinMid: ". We have designed a step by step curriculum to help you master this topic.",
    aiWelcomeJoinMilestones: "Here are the target milestones we will cover together:",
    aiWelcomeJoinStart: "Let us start with Step 1: ",
    aiWelcomeJoinInstruct: ". I will guide you through this step and ensure you fully understand the core concepts.",
    aiWelcomeJoinQuestion: "To begin, what is your current understanding of this first step, or would you like me to explain the key concepts to you?",
    aiPromptPlaceholder: "Type your homework problem or academic questions here...",
    aiSendButton: "Send Message",
    aiScanWelcome: "Absolutely! I have the scan content references fresh. Let's do a deep-dive tutorial. Ask me anything about the calculations, steps, rules or diagrams!",
    aiSolvingLoader: "Compiling dynamic Markdown math, logical grids, and checks..."
  },
  FRENCH: {
    // Nav & General
    home: "Accueil",
    tutors: "Tuteurs",
    students: "Étudiants",
    community: "Communauté",
    signIn: "Se Connecter",
    signOut: "Se Déconnecter",
    welcome: "Bienvenue",
    studentPortal: "Portail Étudiant",
    
    // Landing Page
    heroTitle: "Là où l'apprentissage rencontre le soutien",
    heroDesc: "NC.edu est une plateforme d'apprentissage intelligente qui connecte les étudiants qui excellent avec ceux qui ont besoin d'aide.",
    joinAsStudent: "Nous Rejoindre",
    applyAsTutor: "Devenir Tuteur",
    pathwaysHeading: "Parcours d'Apprentissage Spécialisés",
    welcomeBack: "Bon retour ! Votre ID Étudiant est",
    upgradePro: "Devenir Pro",
    communityTitle: "Construisons l'Avenir Ensemble",
    communityDesc: "À NC.edu, personne n'apprend seul. Chaque étudiant fort devient un mentor et chaque étudiant en difficulté reçoit du soutien.",
    joinCommunity: "Rejoindre la Communauté",
    privacyText: "Confidentialité",
    termsText: "Conditions",
    contactText: "Contact",
    
    peerTutoring: "Tutorat par les Pairs",
    peerTutoringDesc: "Les étudiants qui maîtrisent des matières peuvent enseigner aux autres de façon simple et amicale.",
    studyGroups: "Groupes d'Étude",
    studyGroupsDesc: "Créez ou rejoignez des groupes d'étude pour préparer ensemble vos examens et devoirs.",
    liveChat: "Chat en Direct",
    liveChatDesc: "Posez instantanément vos questions et recevez des explications des meilleurs étudiants.",
    getStarted: "Commencer",
    premiumFeature: "Fonctionnalité Premium",
    upgradeDesc: "Passez à l'offre supérieure pour rejoindre les groupes d'étude et les tchats.",
    upgradeNow: "Mettre à niveau",
    
    // Student Dashboard
    studentDashboardTitle: "Tableau de Bord Étudiant de NC.edu",
    studentDashboardDesc: "Votre passerelle vers l'excellence académique et le tutorat d'experts.",
    welcomeStudent: "Bienvenue Étudiant",
    welcomeStudentDesc: "Trouvez des tuteurs experts, posez vos questions complexes, rejoignez des groupes d'étude et maîtrisez votre réussite académique avec nos outils IA.",
    studentExperiences: "Témoignages Étudiants",
    
    allSubjectsTitle: "Toutes les Matières",
    allSubjectsDesc: "Connectez-vous avec les meilleurs tuteurs dans tous les domaines - des mathématiques à la littérature.",
    findTutorBtn: "Trouver un Tuteur",
    
    joinClassTitle: "Rejoindre un Cours",
    joinClassDesc: "Apprenez des concepts complexes à travers des leçons structurées et des plannings guidés par l'IA.",
    joinClassBtn: "Rejoindre",
    
    askQuestionsTitle: "Poser des Questions",
    askQuestionsDesc: "Obtenez des réponses instantanées pour vos exercices difficiles grâce à notre IA performante.",
    askQuestionBtn: "Poser une Question",
    
    scanAndSolveTitle: "IA Scanner & Résoudre",
    scanAndSolveDesc: "Scannez ou prenez en photo n'importe quelle équation manuscrite, devoir, diagramme ou note. Obtenez immédiatement des solutions étape par étape !",
    scanAndSolveBtn: "Scanner & Résoudre",

    // Action wizard / AI Chat
    aiWelcomeAsk: "Bonjour ! Je suis votre tuteur académique IA premium. Je suis prêt à vous aider à maîtriser le sujet : ",
    aiWelcomeAskSuffix: " ! N'hésitez pas à poser vos questions ou à demander des exercices d'entraînement.",
    aiWelcomeJoin: "Bonjour ! Bienvenue dans votre parcours d'étude premium pour ",
    aiWelcomeJoinMid: ". Nous avons conçu un programme étape par étape pour vous aider à maîtriser ce sujet.",
    aiWelcomeJoinMilestones: "Voici les étapes clés que nous allons couvrir ensemble :",
    aiWelcomeJoinStart: "Commençons par l'Étape 1 : ",
    aiWelcomeJoinInstruct: ". Je vais vous guider à travers cette étape et m'assurer que vous comprenez bien les concepts de base.",
    aiWelcomeJoinQuestion: "Pour commencer, quel est votre niveau de compréhension actuel de cette première étape, ou souhaitez-vous que je vous explique les concepts clés ?",
    aiPromptPlaceholder: "Saisissez votre devoir ou vos questions académiques ici...",
    aiSendButton: "Envoyer",
    aiScanWelcome: "Absolument ! J'ai les références du scan en mémoire. Commençons un tutorat approfondi. Posez-moi des questions sur les calculs, étapes, règles ou schémas !",
    aiSolvingLoader: "Compilation des mathématiques dynamiques, grilles logiques et vérifications..."
  },
  CHINESE: {
    // Nav & General
    home: "首页",
    tutors: "导师",
    students: "学生",
    community: "社区",
    signIn: "登录",
    signOut: "退出登录",
    welcome: "欢迎",
    studentPortal: "学生门户",
    
    // Landing Page
    heroTitle: "学习与支持相遇的地方",
    heroDesc: "NC.edu 智能学习平台致力于连接追求卓越的尖子生与需要学业支持的同学们，实现共同进步。",
    joinAsStudent: "学生加入",
    applyAsTutor: "申请成为导师",
    pathwaysHeading: "专业学习路径",
    welcomeBack: "欢迎回来！您的学生 ID 是",
    upgradePro: "升级至 Pro 尊享版",
    communityTitle: "共创美好未来",
    communityDesc: "在 NC.edu，没有人在孤军奋战。每一位优秀的学生都将成为导师，每一位遇到学业阻碍的学生都将得到全面支持。",
    joinCommunity: "加入学习社区",
    privacyText: "隐私政策",
    termsText: "服务条款",
    contactText: "联系我们",
    
    peerTutoring: "同伴互助辅导",
    peerTutoringDesc: "对学科有深刻理解的学生能够以简单、友好的方式指导其他同学。",
    studyGroups: "学习小组",
    studyGroupsDesc: "创建或加入学习小组，共同准备考试并一起完成作业。",
    liveChat: "即时聊天",
    liveChatDesc: "即时提出问题，并获得优秀学生的专业解答与分析。",
    getStarted: "立即开始",
    premiumFeature: "高级尊享功能",
    upgradeDesc: "升级账户以加入学习小组和即时聊天功能。",
    upgradeNow: "立即升级",
    
    // Student Dashboard
    studentDashboardTitle: "NC.edu 学生仪表板",
    studentDashboardDesc: "通往卓越学术表现和专家辅导的桥梁。",
    welcomeStudent: "欢迎学生",
    welcomeStudentDesc: "寻找专业导师，提出您在学习中遇到的难题，加入协作学习小组，并利用 AI 工具全面提升学业成绩。",
    studentExperiences: "学生心得与反馈",
    
    allSubjectsTitle: "所有学科",
    allSubjectsDesc: "连接各个学术领域的顶尖导师——涵盖从数学到文学的全部课程。",
    findTutorBtn: "寻找导师",
    
    joinClassTitle: "加入班级",
    joinClassDesc: "通过结构化课程以及由人工智能引导的学习进度表，轻松攻克复杂课题。",
    joinClassBtn: "加入课程",
    
    askQuestionsTitle: "提问释疑",
    askQuestionsDesc: "使用我们经过专家专项训练的人工智能模型，即时获得棘手难题的详细解题步骤。",
    askQuestionBtn: "立即提问",
    
    scanAndSolveTitle: "AI 拍照搜题",
    scanAndSolveDesc: "扫描或拍摄您的手写方程式、家庭作业、科学图表或课堂笔记。即刻获取极其详尽的逐步解答！",
    scanAndSolveBtn: "扫描并完成",

    // Action wizard / AI Chat
    aiWelcomeAsk: "您好！我是您的高级 AI 学术导师。我已经准备好帮助您掌握这门学科了：",
    aiWelcomeAskSuffix: "！请随时提出您的问题或要求做一些练习题。",
    aiWelcomeJoin: "您好！欢迎来到您的专属高级学习路径：",
    aiWelcomeJoinMid: "。我们设计了循序渐进的专属课程，全力协助您攻克这一课题。",
    aiWelcomeJoinMilestones: "以下是我们将共同完成的关键学习里程碑：",
    aiWelcomeJoinStart: "让我们从第一步开始：",
    aiWelcomeJoinInstruct: "。我将引导您完成这一步骤，并确保您充分布局并掌握核心概念。",
    aiWelcomeJoinQuestion: "首先，您对第一步的了解情况如何？或者您希望我为您详细讲解它的核心要点吗？",
    aiPromptPlaceholder: "在此处输入您的作业题目或学术疑问...",
    aiSendButton: "发送消息",
    aiScanWelcome: "没问题！我已完美保存了您拍摄扫描的全部内容。让我们开始深度的专属辅导。请向我提问关于计算步骤、规则或图表的任何疑问！",
    aiSolvingLoader: "正在动态编译数学公式、逻辑矩阵并执行严密检查..."
  },
  SPANISH: {
    // Nav & General
    home: "Inicio",
    tutors: "Tutores",
    students: "Estudiantes",
    community: "Comunidad",
    signIn: "Iniciar Sesión",
    signOut: "Cerrar Sesión",
    welcome: "Bienvenido",
    studentPortal: "Portal del Estudiante",
    
    // Landing Page
    heroTitle: "Donde el aprendizaje se une al apoyo",
    heroDesc: "NC.edu es una plataforma de aprendizaje inteligente que conecta a estudiantes sobresalientes con estudiantes que necesitan ayuda.",
    joinAsStudent: "Unirse como Estudiante",
    applyAsTutor: "Postularse como Tutor",
    pathwaysHeading: "Rutas de Aprendizaje Especializadas",
    welcomeBack: "¡Bienvenido de nuevo! Tu ID de Estudiante es",
    upgradePro: "Mejorar a Pro",
    communityTitle: "Construyamos el Futuro Juntos",
    communityDesc: "En NC.edu, nadie aprende solo. Cada estudiante capacitado se convierte en mentor, y cada estudiante con dificultades recibe apoyo.",
    joinCommunity: "Unirse a la Comunidad",
    privacyText: "Privacidad",
    termsText: "Condiciones",
    contactText: "Contacto",
    
    peerTutoring: "Tutoría entre Compañeros",
    peerTutoringDesc: "Los estudiantes que comprenden profundamente los temas pueden enseñar de manera simple y constructiva.",
    studyGroups: "Grupos de Estudio",
    studyGroupsDesc: "Crea o únete a grupos de estudio y prepárense juntos para exámenes y proyectos.",
    liveChat: "Chat en Vivo",
    liveChatDesc: "Pregunta al instante y recibe explicaciones claras de estudiantes sobresalientes.",
    getStarted: "Comenzar",
    premiumFeature: "Función Premium",
    upgradeDesc: "Actualiza tu plan para unirte a los grupos de estudio y chats en vivo.",
    upgradeNow: "Mejorar Ahora",
    
    // Student Dashboard
    studentDashboardTitle: "Panel de Control Estudiantil de NC.edu",
    studentDashboardDesc: "Tu puerta de entrada a la excelencia académica y tutorías de primer nivel.",
    welcomeStudent: "Bienvenido Estudiante",
    welcomeStudentDesc: "Encuentra tutores calificados, resuelve tus dudas más complejas, únete a grupos de estudio y domina tu rendimiento académico con herramientas basadas en IA.",
    studentExperiences: "Experiencias de Estudiantes",
    
    allSubjectsTitle: "Todas las Materias",
    allSubjectsDesc: "Conéctate con tutores especializados en cualquier área académica, desde matemáticas hasta literatura.",
    findTutorBtn: "Buscar Tutor",
    
    joinClassTitle: "Unirse a Clase",
    joinClassDesc: "Aprende temas complejos mediante lecciones de ritmo diario y cronogramas guiados por IA.",
    joinClassBtn: "Unirse a Clase",
    
    askQuestionsTitle: "Hacer Preguntas",
    askQuestionsDesc: "Obtén respuestas instantáneas para problemas difíciles utilizando nuestro modelo de IA entrenado por expertos.",
    askQuestionBtn: "Hacer Pregunta",
    
    scanAndSolveTitle: "IA Escanear y Resolver",
    scanAndSolveDesc: "Escanea o toma una foto de cualquier ecuación escrita a mano, tarea o diagrama. ¡Obtén soluciones inmediatas y paso a paso!",
    scanAndSolveBtn: "Escanear y Resolver",

    // Action wizard / AI Chat
    aiWelcomeAsk: "¡Hola! Soy tu tutor académico premium de IA. Estoy listo para ayudarte a dominar la materia de: ",
    aiWelcomeAskSuffix: " ¡No dudes en hacer tus preguntas o solicitar ejercicios de práctica!",
    aiWelcomeJoin: "¡Hola! Bienvenido a tu plan de estudio premium para ",
    aiWelcomeJoinMid: ". Hemos diseñado un plan paso a paso para ayudarte a dominar este tema.",
    aiWelcomeJoinMilestones: "Aquí están los hitos que completaremos juntos:",
    aiWelcomeJoinStart: "Comencemos con el Paso 1: ",
    aiWelcomeJoinInstruct: ". Te guiaré paso a paso a través de este bloque y me aseguraré de que comprendas los conceptos clave.",
    aiWelcomeJoinQuestion: "Para empezar, ¿cuál es tu nivel de comprensión de este primer paso, o te gustaría que te explique los conceptos iniciales?",
    aiPromptPlaceholder: "Escribe tu problema de tarea o tus dudas aquí...",
    aiSendButton: "Enviar Mensaje",
    aiScanWelcome: "¡Por supuesto! He procesado el contenido de tu escaneo. Iniciemos una tutoría detallada. ¡Pregúntame cualquier detalle sobre los cálculos, pasos, reglas o diagramas!",
    aiSolvingLoader: "Compilando fórmulas matemáticas, diagramas lógicos y revisiones..."
  }
};
